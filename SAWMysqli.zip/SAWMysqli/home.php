<html>
<title>Home</title>
<style type="text/css">
<!--
.style2 {font-size: 24px}
-->
</style>
<head>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/menu.css" type="text/css" media="screen"> 
</head>

<body>
<div id="content" align="center">
<div class="body">
<div id="content" align="center">
<div class="header">
<img src="images/headernew.jpg"></div>

<div class="menu">
<ul id="nav">
        <li ><a title="Home "href="home.php"><b><font >Home</font></b></a></li>
		<li><a href="input.php">Input Data</a></li>
		<li><a href="view.php">Lihat Data</a></li>
		<li><a href="normalisasi.php">Normalisasi</a></li>
		<li><a href="rangking.php">Hasil</a></li>
		<li><a href="index.php">Logout</a></li>
	   
  
        <table width="948" height="557" border="0">
          <tr>
            <td height="463" colspan="4"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="1072" height="528" hspace="0" vspace="0" align="center">
              <param name="flash_component" value="ImageViewer.swc">
              <param name="movie" value="images/saw.swf">
              <param name="quality" value="high">
              <param name="FlashVars" value="flashlet={imageLinkTarget:'_blank',captionFont:'Verdana',titleFont:'Verdana',showControls:false,frameShow:false,slideDelay:3,captionSize:10,titleSize:10,transitionsType:'Random',titleColor:#333333,slideAutoPlay:true,slideLoop:true,frameThickness:2,imageLinks:['http://macromedia.com/','http://macromedia.com/','http://macromedia.com/'],imageCaptions:[],frameColor:#00FF00,imageURLs:['images/10.jpg','images/6.jpg','images/5.jpg','images/9.jpg','images/3.jpg','images/12.jpg','images/4.jpg','images/2.jpg','images/1.jpg','images/7.jpg','images/8.jpg','images/11.jpg','images/13.jpg']}">
              <embed src="images/saw.swf" width="1072" height="528" hspace="0" vspace="0" align="left" quality="high" flashvars="flashlet={imageLinkTarget:'_blank',captionFont:'Verdana',titleFont:'Verdana',showControls:false,frameShow:false,slideDelay:3,captionSize:10,titleSize:10,transitionsType:'Random',titleColor:#333333,slideAutoPlay:true,slideLoop:true,frameThickness:2,imageLinks:['http://macromedia.com/','http://macromedia.com/','http://macromedia.com/'],imageCaptions:[],frameColor:#00FF00,imageURLs:['images/10.jpg','images/6.jpg','images/5.jpg','images/9.jpg','images/3.jpg','images/12.jpg','images/4.jpg','images/2.jpg','images/1.jpg','images/7.jpg','images/8.jpg','images/11.jpg','images/13.jpg']}" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash"> </embed>
            </object></td>
          </tr>
          <tr>
            <td width="262" height="88">&nbsp;</td>
            <td width="262">&nbsp;</td>
            <td width="262">&nbsp;</td>
            <td width="302">&nbsp;</td>
          </tr>
</table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
</body>
</html>